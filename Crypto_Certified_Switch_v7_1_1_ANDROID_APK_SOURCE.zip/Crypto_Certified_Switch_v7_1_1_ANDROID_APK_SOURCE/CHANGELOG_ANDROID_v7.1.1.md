# Crypto Certified Switch — Android v7.1.1

## Alterações

- TESTAR CONFIG agora executa diagnóstico real, sem enviar transações:
  - conectividade com a internet;
  - Helius / Solana;
  - RPC Solana próprio/fallback;
  - Ethereum RPC;
  - BNB Chain RPC;
  - Telegram Bot;
  - acesso do bot ao Chat ID;
  - Bridge público HTTPS e endpoint `/health`;
  - validação das carteiras de origem/destino.
- O diagnóstico roda em thread separada para não congelar a interface Kivy.
- O relatório aparece dentro da própria tela com ✅ / ⚠️ / ❌.
- A área inferior ganhou margem de segurança para não ficar coberta pela barra de navegação do Android.
- Versão do APK atualizada para 7.1.1.
- A toolchain Android, NDK 29, API 35, minAPI 26 e `p4a.branch = develop` foram preservados porque a base atual já compilou com sucesso no GitHub Actions.
