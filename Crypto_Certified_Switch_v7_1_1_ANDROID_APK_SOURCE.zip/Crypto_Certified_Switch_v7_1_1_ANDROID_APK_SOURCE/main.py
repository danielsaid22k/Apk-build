from __future__ import annotations

import os
import threading
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

from android_config import ensure_runtime, load_settings, save_settings

PACKAGE_ROOT = Path(__file__).resolve().parent


class CCSApp(App):
    title = "Crypto Certified Switch"

    def build(self):
        runtime = Path(self.user_data_dir)
        self.cfg_path, self.env_path = ensure_runtime(PACKAGE_ROOT, runtime)
        self.config, self.env = load_settings(self.cfg_path, self.env_path)

        root = BoxLayout(
            orientation="vertical",
            spacing=dp(8),
            padding=(dp(10), dp(10), dp(10), dp(8)),
        )

        title = Label(
            text="[b]Crypto Certified Switch[/b]\nAndroid Config Center · v7.1.1",
            markup=True,
            size_hint_y=None,
            height=dp(70),
        )
        root.add_widget(title)

        sc = ScrollView()
        form = GridLayout(cols=1, spacing=dp(8), size_hint_y=None)
        form.bind(minimum_height=form.setter("height"))
        sc.add_widget(form)
        root.add_widget(sc)

        self.fields = {}
        self.checks = {}

        self._section(form, "APIs / RPC")
        self._field(form, "HELIUS_API_KEY", "Helius API Key", secret=True)
        self._field(form, "SOLANA_RPC_URL", "Solana RPC URL")
        self._field(form, "SOLANA_RPC_FALLBACK_URL", "Solana RPC fallback")
        self._field(form, "ETHEREUM_RPC_URL", "Ethereum RPC URL")
        self._field(form, "BNB_RPC_URL", "BNB Chain RPC URL")

        self._section(form, "Telegram")
        self._field(form, "TELEGRAM_BOT_TOKEN", "Token do bot", secret=True)
        self._field(form, "TELEGRAM_CHAT_ID", "Chat ID")
        self._field(form, "APPROVAL_BRIDGE_PUBLIC_URL", "Bridge público HTTPS")

        self._section(form, "Carteiras de origem")
        for network, label in (
            ("ethereum", "Phantom Ethereum"),
            ("bnb", "Binance Web3 BNB"),
            ("solana", "Phantom Solana"),
        ):
            self._wallet(form, network, label, False)

        self._section(form, "Carteiras de destino")
        for network, label in (
            ("ethereum", "Destino Ethereum"),
            ("bnb", "Destino BNB"),
            ("solana", "Destino Solana"),
        ):
            self._wallet(form, network, label, True)

        self.status = Label(
            text="Configurações privadas ficam no armazenamento interno do app.",
            size_hint_y=None,
            height=dp(70),
            halign="left",
            valign="top",
        )
        self.status.bind(width=lambda inst, width: setattr(inst, "text_size", (width, None)))
        self.status.bind(texture_size=self._resize_status)
        form.add_widget(self.status)

        # Área inferior com espaço extra para não ficar sob a barra de navegação do Android.
        bottom = BoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(86),
            padding=(0, 0, 0, dp(24)),
        )
        buttons = BoxLayout(size_hint_y=None, height=dp(58), spacing=dp(8))
        self.save_button = Button(text="SALVAR", on_release=self.save)
        self.test_button = Button(text="TESTAR CONFIG", on_release=self.test_config)
        buttons.add_widget(self.save_button)
        buttons.add_widget(self.test_button)
        bottom.add_widget(buttons)
        root.add_widget(bottom)

        return root

    def _resize_status(self, instance, texture_size):
        # Garante altura suficiente para o relatório completo dentro do ScrollView.
        instance.height = max(dp(70), texture_size[1] + dp(24))

    def _section(self, form, text):
        form.add_widget(
            Label(
                text=f"[b]{text}[/b]",
                markup=True,
                size_hint_y=None,
                height=dp(38),
            )
        )

    def _field(self, form, key, label, secret=False):
        form.add_widget(
            Label(
                text=label,
                size_hint_y=None,
                height=dp(28),
                halign="left",
            )
        )
        ti = TextInput(
            text=self.env.get(key, ""),
            password=secret,
            multiline=False,
            size_hint_y=None,
            height=dp(48),
        )
        self.fields[key] = ti
        form.add_widget(ti)

    def _wallet(self, form, network, label, destination):
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        cb = CheckBox(size_hint_x=None, width=dp(46))
        inp = TextInput(multiline=False)

        if destination:
            item = self.config.get("destination_wallets", {}).get(network, {})
            key = f"dest:{network}"
        else:
            item = next(
                (w for w in self.config.get("wallets", []) if w.get("network") == network),
                {},
            )
            key = f"orig:{network}"

        cb.active = bool(item.get("enabled"))
        inp.text = str(item.get("address", ""))
        self.checks[key] = cb
        self.fields[key] = inp

        row.add_widget(cb)
        row.add_widget(Label(text=label, size_hint_x=0.36))
        row.add_widget(inp)
        form.add_widget(row)

    def save(self, *_):
        for key, ti in self.fields.items():
            if ":" not in key:
                self.env[key] = ti.text.strip()

        nets = self.config.setdefault("networks", {})
        nets.setdefault("ethereum", {})["rpc_url"] = self.env["ETHEREUM_RPC_URL"]
        nets.setdefault("bnb", {})["rpc_url"] = self.env["BNB_RPC_URL"]

        for network in ("ethereum", "bnb", "solana"):
            wallet = next(
                (x for x in self.config.get("wallets", []) if x.get("network") == network),
                None,
            )
            if wallet:
                wallet["address"] = self.fields[f"orig:{network}"].text.strip()
                wallet["enabled"] = self.checks[f"orig:{network}"].active

            destination = self.config.setdefault("destination_wallets", {}).setdefault(network, {})
            destination["address"] = self.fields[f"dest:{network}"].text.strip()
            destination["enabled"] = self.checks[f"dest:{network}"].active

        save_settings(self.cfg_path, self.env_path, self.config, self.env)

        for key, value in self.env.items():
            os.environ[key] = value

        self.status.text = "✅ Configurações salvas no armazenamento privado do aplicativo."

    def test_config(self, *_):
        # Primeiro salva exatamente o que está visível na tela.
        self.save()
        self.test_button.disabled = True
        self.save_button.disabled = True
        self.status.text = "🔎 Testando internet, RPCs, Telegram, Bridge e carteiras..."

        threading.Thread(target=self._run_test_config, daemon=True).start()

    def _run_test_config(self):
        try:
            from android_diagnostics import format_report, run_diagnostics

            results, summary = run_diagnostics(self.config, self.env)
            report = format_report(results, summary)
        except Exception as exc:
            report = f"❌ Falha inesperada no diagnóstico: {exc}"

        Clock.schedule_once(lambda _dt: self._finish_test(report), 0)

    def _finish_test(self, report: str):
        self.status.text = report
        self.test_button.disabled = False
        self.save_button.disabled = False


if __name__ == "__main__":
    CCSApp().run()
