CRYPTO CERTIFIED SWITCH v7.1.1 — ANDROID

O que mudou:
- TESTAR CONFIG agora testa de verdade Internet, Helius/Solana, Solana RPC/fallback,
  Ethereum RPC, BNB RPC, Telegram Bot, Chat ID, Bridge HTTPS /health e carteiras.
- O teste roda em segundo plano para não travar a interface.
- A área inferior dos botões ganhou margem contra a barra de navegação do Android.
- A configuração de build que gerou APK com sucesso foi preservada:
  API 35, minAPI 26, NDK 29, p4a develop, Python/Kivy.

GitHub:
1. Substitua os arquivos do repositório pelos arquivos desta pasta.
2. Faça commit/push para a branch main.
3. Abra Actions > Gerar APK Android Final > Run workflow.
4. Ao terminar verde, baixe o artifact Crypto-Certified-Switch-v7.1.1-APK.

No app:
- SALVAR grava as configurações no armazenamento privado do Android.
- TESTAR CONFIG faz diagnóstico, mas NÃO envia transação.
- Bridge HTTPS é opcional para a configuração básica, porém necessário para os links públicos
  de revisão/abertura usados no fluxo do Telegram.
