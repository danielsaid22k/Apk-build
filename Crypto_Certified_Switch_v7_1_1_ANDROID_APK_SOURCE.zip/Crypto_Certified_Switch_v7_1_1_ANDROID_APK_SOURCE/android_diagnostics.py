from __future__ import annotations

from dataclasses import dataclass
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import os

from app.bridge_url import check_health, validate_public_https
from app.http import HttpError, request_json, telegram_api
from app.wallets import validate as validate_wallets


@dataclass
class CheckResult:
    label: str
    state: str  # ok | warn | error
    detail: str

    @property
    def icon(self) -> str:
        return {"ok": "✅", "warn": "⚠️", "error": "❌"}.get(self.state, "ℹ️")

    def line(self) -> str:
        suffix = f" — {self.detail}" if self.detail else ""
        return f"{self.icon} {self.label}{suffix}"


def _internet(timeout: int = 6) -> CheckResult:
    request = Request(
        "https://clients3.google.com/generate_204",
        headers={"User-Agent": "CryptoCertifiedSwitch/7.1.1"},
        method="GET",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            if response.status in (200, 204):
                return CheckResult("Internet", "ok", "online")
            return CheckResult("Internet", "error", f"HTTP {response.status}")
    except (HTTPError, URLError, OSError) as exc:
        return CheckResult("Internet", "error", str(exc))
    except Exception as exc:
        return CheckResult("Internet", "error", str(exc))


def _json_rpc(label: str, url: str, method: str, params: list, timeout: int = 8) -> CheckResult:
    url = str(url or "").strip()
    if not url:
        return CheckResult(label, "warn", "não configurado")
    if not url.lower().startswith(("https://", "http://")):
        return CheckResult(label, "error", "URL inválida")
    try:
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params,
        }
        response = request_json(url, "POST", payload, timeout=timeout)
        if not isinstance(response, dict):
            return CheckResult(label, "error", "resposta inválida")
        if response.get("error"):
            return CheckResult(label, "error", str(response.get("error"))[:160])
        if "result" not in response:
            return CheckResult(label, "error", "resultado RPC ausente")
        return CheckResult(label, "ok", "online")
    except Exception as exc:
        return CheckResult(label, "error", str(exc)[:180])


def _helius(api_key: str) -> CheckResult:
    key = str(api_key or "").strip()
    if not key:
        return CheckResult("Helius / Solana", "warn", "API Key não configurada")
    url = f"https://mainnet.helius-rpc.com/?api-key={key}"
    result = _json_rpc("Helius / Solana", url, "getHealth", [], timeout=8)
    if result.state == "ok":
        result.detail = "online"
    return result


def _solana_rpc(url: str, fallback_url: str) -> CheckResult:
    primary = str(url or "").strip()
    fallback = str(fallback_url or "").strip()
    if not primary and not fallback:
        return CheckResult("Solana RPC próprio", "warn", "não configurado")

    if primary:
        first = _json_rpc("Solana RPC próprio", primary, "getHealth", [], timeout=8)
        if first.state == "ok":
            return first
        if not fallback:
            return first

    second = _json_rpc("Solana RPC fallback", fallback, "getHealth", [], timeout=8)
    if second.state == "ok":
        return CheckResult("Solana RPC próprio", "ok", "fallback online")
    return CheckResult("Solana RPC próprio", "error", second.detail)


def _telegram(token: str, chat_id: str) -> list[CheckResult]:
    token = str(token or "").strip()
    chat_id = str(chat_id or "").strip()

    if not token:
        return [
            CheckResult("Telegram Bot", "error", "token ausente"),
            CheckResult("Telegram Chat ID", "error", "Chat ID ausente" if not chat_id else "não testado"),
        ]

    try:
        me = telegram_api(token, "getMe", {})
        if not me.get("ok"):
            return [
                CheckResult("Telegram Bot", "error", "token rejeitado"),
                CheckResult("Telegram Chat ID", "error", "não testado"),
            ]
        bot_result = me.get("result") or {}
        username = str(bot_result.get("username") or "bot")
        bot_check = CheckResult("Telegram Bot", "ok", f"@{username}")
    except Exception as exc:
        return [
            CheckResult("Telegram Bot", "error", str(exc)[:160]),
            CheckResult("Telegram Chat ID", "error", "não testado"),
        ]

    if not chat_id:
        return [bot_check, CheckResult("Telegram Chat ID", "error", "ausente")]

    try:
        result = telegram_api(token, "getChat", {"chat_id": chat_id})
        if result.get("ok"):
            return [bot_check, CheckResult("Telegram Chat ID", "ok", "acessível")]
        return [bot_check, CheckResult("Telegram Chat ID", "error", "não acessível pelo bot")]
    except Exception as exc:
        return [bot_check, CheckResult("Telegram Chat ID", "error", str(exc)[:160])]


def _bridge(public_url: str) -> CheckResult:
    value = str(public_url or "").strip()
    if not value:
        return CheckResult("Bridge HTTPS", "warn", "não configurado")
    valid, reason = validate_public_https(value)
    if not valid:
        return CheckResult("Bridge HTTPS", "error", reason)
    ok, detail = check_health(value, timeout=7)
    return CheckResult("Bridge HTTPS", "ok" if ok else "error", detail)


def _wallets(config: dict) -> CheckResult:
    errors = validate_wallets(config)
    if errors:
        return CheckResult("Carteiras", "error", " | ".join(errors[:3]))
    return CheckResult("Carteiras", "ok", "endereços e destinos válidos")


def run_diagnostics(config: dict, env: dict) -> tuple[list[CheckResult], str]:
    """Executa diagnóstico de configuração sem enviar mensagens nem transações."""
    results: list[CheckResult] = []
    results.append(_internet())
    results.append(_helius(env.get("HELIUS_API_KEY", "")))
    results.append(_solana_rpc(
        env.get("SOLANA_RPC_URL", ""),
        env.get("SOLANA_RPC_FALLBACK_URL", ""),
    ))

    eth_url = env.get("ETHEREUM_RPC_URL", "") or config.get("networks", {}).get("ethereum", {}).get("rpc_url", "")
    bnb_url = env.get("BNB_RPC_URL", "") or config.get("networks", {}).get("bnb", {}).get("rpc_url", "")
    results.append(_json_rpc("Ethereum RPC", eth_url, "eth_chainId", [], timeout=8))
    results.append(_json_rpc("BNB Chain RPC", bnb_url, "eth_chainId", [], timeout=8))
    results.extend(_telegram(env.get("TELEGRAM_BOT_TOKEN", ""), env.get("TELEGRAM_CHAT_ID", "")))
    results.append(_bridge(env.get("APPROVAL_BRIDGE_PUBLIC_URL", "")))
    results.append(_wallets(config))

    errors = sum(1 for item in results if item.state == "error")
    warnings = sum(1 for item in results if item.state == "warn")
    oks = sum(1 for item in results if item.state == "ok")

    if errors:
        summary = f"Resultado: {oks} OK · {warnings} aviso(s) · {errors} erro(s)"
    elif warnings:
        summary = f"Resultado: {oks} OK · {warnings} aviso(s)"
    else:
        summary = f"Resultado: {oks}/{len(results)} serviços operacionais"

    return results, summary


def format_report(results: list[CheckResult], summary: str) -> str:
    lines = [item.line() for item in results]
    lines.append("")
    lines.append(summary)
    return "\n".join(lines)
